package com.cloudsky.weather.tv;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Android TV adaptation of CloudSky Watch8 Weather.
 * Open-Meteo request fields and geocoding API match the original Wear OS app.
 */
public class MainActivity extends Activity {
    private static final int NAVY = 0xFF081522;
    private static final int MUTED = 0xFFAAC1D8;
    private static final int BLUE = 0xFF75C6FF;
    private static final int WHITE = Color.WHITE;
    private static final int PANEL = 0xFF102338;
    private static final int TILE = 0xFF1D3850;
    private static final int REQUEST_LOCATION = 61;
    private static final String PREFS = "cloudsky_weather";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private double latitude = -34.6037;
    private double longitude = -58.3816;
    private String city = "Buenos Aires, Argentina";
    private boolean destroyed = false;
    private int requestSequence = 0;
    private boolean compact = false;
    private int screenWidthDp;

    private TextView cityView;
    private TextView statusView;
    private TextView weatherEmoji;
    private TextView tempView;
    private TextView weatherView;
    private TextView updateView;
    private final TextView[] detailValue = new TextView[4];
    private LinearLayout hourRow;
    private LinearLayout daysList;
    private LinearLayout hero;
    private EditText cityInput;
    private TextView searchStatus;
    private LinearLayout searchResults;
    private boolean searchPage = false;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private boolean awaitingLocation = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        latitude = Double.longBitsToDouble(prefs.getLong("lat", Double.doubleToRawLongBits(latitude)));
        longitude = Double.longBitsToDouble(prefs.getLong("lon", Double.doubleToRawLongBits(longitude)));
        city = prefs.getString("city", city);
        buildScreen();
        String cached = prefs.getString("cache", "");
        if (!cached.isEmpty()) {
            try {
                render(new JSONObject(cached));
                statusView.setText("缓存天气 · 正在检查更新");
            } catch (Exception ignored) { }
        }
        long savedAt = prefs.getLong("cached_at", 0L);
        if (cached.isEmpty() || System.currentTimeMillis() - savedAt > 10 * 60 * 1000L) {
            loadWeather();
        } else {
            statusView.setText("天气已更新 · 可在下方设置中刷新");
        }
    }

    private void buildScreen() {
        searchPage = false;
        float density = getResources().getDisplayMetrics().density;
        int screenHeightDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        screenWidthDp = Math.round(getResources().getDisplayMetrics().widthPixels / density);
        compact = screenHeightDp < 480;
        int side = Math.max(24, Math.min(56, screenWidthDp / 20));
        int verticalGutter = compact ? 9 : 14;
        int firstViewportHeight = Math.max(300, screenHeightDp - verticalGutter * 2);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(NAVY);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(side), dp(verticalGutter), dp(side), dp(verticalGutter));
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(body);
        setContentView(scroll);

        // Exactly one TV screen: weather now / next 24 hours / next seven days.
        LinearLayout firstPage = new LinearLayout(this);
        firstPage.setOrientation(LinearLayout.VERTICAL);
        body.addView(firstPage, new LinearLayout.LayoutParams(-1, dp(firstViewportHeight)));

        hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(compact ? 15 : 24), dp(compact ? 9 : 13),
                dp(compact ? 15 : 24), dp(compact ? 8 : 12));
        hero.setBackground(heroBackground(true, 1));
        firstPage.addView(hero, new LinearLayout.LayoutParams(-1, 0, 0.36f));

        LinearLayout heroHeader = horizontal(Gravity.CENTER_VERTICAL);
        hero.addView(heroHeader, new LinearLayout.LayoutParams(-1, dp(compact ? 21 : 26)));
        TextView brand = text("云端天气   /   CLOUDSKY TV", compact ? 15 : 19, WHITE, true);
        heroHeader.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        statusView = text("正在获取天气…", compact ? 11 : 14, 0xFFE2EDF7, false);
        statusView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        statusView.setSingleLine(true);
        statusView.setEllipsize(TextUtils.TruncateAt.END);
        heroHeader.addView(statusView, new LinearLayout.LayoutParams(0, -2, 1));

        cityView = text(city, compact ? 17 : 23, WHITE, true);
        cityView.setSingleLine(true);
        cityView.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams cityParams = new LinearLayout.LayoutParams(-1, dp(compact ? 23 : 31));
        cityParams.topMargin = dp(2);
        hero.addView(cityView, cityParams);

        LinearLayout overview = horizontal(Gravity.CENTER_VERTICAL);
        hero.addView(overview, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout current = horizontal(Gravity.CENTER_VERTICAL);
        overview.addView(current, new LinearLayout.LayoutParams(0, -1, 1.15f));
        weatherEmoji = text("🌤️", compact ? 36 : 55, WHITE, false);
        weatherEmoji.setGravity(Gravity.CENTER);
        current.addView(weatherEmoji, new LinearLayout.LayoutParams(dp(compact ? 65 : 93), -1));
        tempView = text("--°", compact ? 43 : 63, WHITE, true);
        tempView.setGravity(Gravity.CENTER_VERTICAL);
        tempView.setSingleLine(true);
        current.addView(tempView);
        weatherView = text("加载中", compact ? 15 : 22, WHITE, false);
        weatherView.setGravity(Gravity.BOTTOM);
        weatherView.setSingleLine(true);
        weatherView.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams descP = new LinearLayout.LayoutParams(-2, -2);
        descP.leftMargin = dp(8);
        current.addView(weatherView, descP);

        LinearLayout facts = new LinearLayout(this);
        facts.setOrientation(LinearLayout.VERTICAL);
        overview.addView(facts, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout topFacts = horizontal(Gravity.CENTER_VERTICAL);
        LinearLayout bottomFacts = horizontal(Gravity.CENTER_VERTICAL);
        facts.addView(topFacts, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams bottomFactsP = new LinearLayout.LayoutParams(-1, 0, 1);
        bottomFactsP.topMargin = dp(5);
        facts.addView(bottomFacts, bottomFactsP);
        addDetail(topFacts, 0, "🌡  体感温度");
        addDetail(topFacts, 1, "💧  空气湿度");
        addDetail(bottomFacts, 2, "🍃  当前风速");
        addDetail(bottomFacts, 3, "☂  当前降水");

        // Keep 24 hourly cards available via native DPAD-left/right focus scrolling.
        LinearLayout hours = forecastSection(firstPage, "未来24小时", "遥控器 ← → 浏览全部24小时", 0.285f);
        HorizontalScrollView hourScroll = new HorizontalScrollView(this);
        hourScroll.setHorizontalScrollBarEnabled(false);
        hourScroll.setFillViewport(false);
        hourScroll.setSmoothScrollingEnabled(true);
        hours.addView(hourScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        hourRow = horizontal(Gravity.CENTER_VERTICAL);
        hourScroll.addView(hourRow, new HorizontalScrollView.LayoutParams(-2, -1));

        LinearLayout days = forecastSection(firstPage, "未来7天天气", "7天一屏查看   ·   ↓  下翻进入设置", 0.355f);
        daysList = horizontal(Gravity.CENTER_VERTICAL);
        days.addView(daysList, new LinearLayout.LayoutParams(-1, 0, 1));

        // Second TV screen: settings and diagnostic details (vertical DPAD scroll).
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.setPadding(dp(26), dp(22), dp(26), dp(28));
        tools.setBackground(round(PANEL, 22));
        LinearLayout.LayoutParams toolsP = new LinearLayout.LayoutParams(-1, -2);
        toolsP.topMargin = dp(22);
        body.addView(tools, toolsP);

        TextView settingsTitle = text("天气设置与详情", compact ? 20 : 28, WHITE, true);
        tools.addView(settingsTitle);
        TextView settingsHint = text("遥控器方向键选择，确定键操作；搜索城市时可用电视键盘输入。",
                compact ? 12 : 16, MUTED, false);
        LinearLayout.LayoutParams sh = new LinearLayout.LayoutParams(-1, -2);
        sh.topMargin = dp(9);
        tools.addView(settingsHint, sh);

        LinearLayout controls = horizontal(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ctlP = new LinearLayout.LayoutParams(-1, dp(compact ? 49 : 60));
        ctlP.topMargin = dp(18);
        tools.addView(controls, ctlP);
        TextView refresh = actionChip("↻  立即刷新天气");
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, -1, 1);
        rp.rightMargin = dp(12);
        controls.addView(refresh, rp);
        refresh.setOnClickListener(v -> loadWeather());
        focusControl(refresh);
        TextView locate = actionChip("⌖  定位当前城市");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.rightMargin = dp(12);
        controls.addView(locate, lp);
        locate.setOnClickListener(v -> locateMe());
        focusControl(locate);
        TextView search = actionChip("⌕  搜索全球城市");
        controls.addView(search, new LinearLayout.LayoutParams(0, -1, 1));
        search.setOnClickListener(v -> showSearchScreen());
        focusControl(search);

        updateView = text("当地时间 --", compact ? 13 : 17, MUTED, false);
        LinearLayout.LayoutParams updateP = new LinearLayout.LayoutParams(-1, -2);
        updateP.topMargin = dp(18);
        tools.addView(updateView, updateP);
        TextView footer = text("天气数据：Open-Meteo.com   ·   城市检索：Open-Meteo Geocoding   ·   自动缓存10分钟", 13, MUTED, false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(13);
        tools.addView(footer, fp);
        TextView backTop = actionChip("↑  返回天气主屏幕");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(51));
        bp.topMargin = dp(20);
        tools.addView(backTop, bp);
        backTop.setOnClickListener(v -> scroll.smoothScrollTo(0, 0));
        focusControl(backTop);
        showSkeleton();
    }

    private LinearLayout forecastSection(LinearLayout parent, String heading, String helper, float weight) {
        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setPadding(dp(compact ? 12 : 18), dp(compact ? 8 : 11),
                dp(compact ? 12 : 18), dp(compact ? 7 : 10));
        section.setBackground(round(PANEL, 21));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 0, weight);
        p.topMargin = dp(compact ? 7 : 9);
        parent.addView(section, p);
        LinearLayout top = horizontal(Gravity.CENTER_VERTICAL);
        section.addView(top, new LinearLayout.LayoutParams(-1, dp(compact ? 22 : 30)));
        TextView t = text(heading, compact ? 17 : 22, WHITE, true);
        top.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        TextView hint = text(helper, compact ? 11 : 14, MUTED, false);
        hint.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(hint, new LinearLayout.LayoutParams(0, -2, 1.15f));
        return section;
    }

    private LinearLayout horizontal(int gravity) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(gravity);
        return layout;
    }

    private void addDetail(LinearLayout row, int index, String title) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(compact ? 7 : 12), dp(1), dp(3), dp(1));
        item.setBackground(round(0x443B7EA3, 12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        if (index % 2 == 1) p.leftMargin = dp(5);
        row.addView(item, p);
        TextView label = text(title, compact ? 11 : 14, 0xFFE1ECF6, false);
        item.addView(label);
        detailValue[index] = text("--", compact ? 15 : 20, WHITE, true);
        detailValue[index].setSingleLine(true);
        item.addView(detailValue[index]);
    }

    private void focusControl(TextView view) {
        view.setFocusable(true);
        view.setFocusableInTouchMode(false);
        view.setOnFocusChangeListener((v, focused) -> view.setBackground(focusBackground(0xFF244967, focused)));
    }

    private void focusTile(LinearLayout tile, int baseColor) {
        tile.setFocusable(true);
        tile.setFocusableInTouchMode(false);
        tile.setOnFocusChangeListener((v, focused) -> tile.setBackground(focusBackground(baseColor, focused)));
    }

    private GradientDrawable focusBackground(int baseColor, boolean focused) {
        GradientDrawable bg = round(focused ? 0xFF2A5A80 : baseColor, 13);
        if (focused) bg.setStroke(dp(3), 0xFFE8F6FF);
        return bg;
    }

    private void showSearchScreen() {
        searchPage = true;
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(NAVY);
        scroll.setPadding(dp(48), dp(28), dp(48), dp(28));
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(outer);
        setContentView(scroll);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(28), dp(24), dp(28), dp(24));
        body.setBackground(round(PANEL, 20));
        outer.addView(body, new LinearLayout.LayoutParams(dp(Math.min(800, screenWidthDp - 115)), -2));
        TextView back = actionChip("‹  返回天气");
        body.addView(back, new LinearLayout.LayoutParams(-1, dp(55)));
        back.setOnClickListener(v -> returnHome());
        focusControl(back);
        TextView heading = text("搜索全球城市", 27, WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(20);
        body.addView(heading, hp);
        TextView hint = text("支持中文 / English / Español，选择结果即可切换城市。", 16, MUTED, false);
        body.addView(hint);
        cityInput = new EditText(this);
        cityInput.setSingleLine(true);
        cityInput.setTextSize(20);
        cityInput.setHint("输入城市名称，例如 Beccar / Shanghai");
        cityInput.setHintTextColor(MUTED);
        cityInput.setTextColor(WHITE);
        cityInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        cityInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        cityInput.setPadding(dp(17), 0, dp(17), 0);
        cityInput.setBackground(round(0xFF23425B, 13));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(62));
        inputParams.topMargin = dp(17);
        body.addView(cityInput, inputParams);
        cityInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                searchCities();
                return true;
            }
            return false;
        });
        TextView go = actionChip("搜索城市");
        LinearLayout.LayoutParams goP = new LinearLayout.LayoutParams(-1, dp(56));
        goP.topMargin = dp(13);
        body.addView(go, goP);
        go.setOnClickListener(v -> searchCities());
        focusControl(go);
        searchStatus = text("选择一个城市即可查看天气", 16, MUTED, false);
        LinearLayout.LayoutParams statusP = new LinearLayout.LayoutParams(-1, -2);
        statusP.topMargin = dp(16);
        body.addView(searchStatus, statusP);
        searchResults = new LinearLayout(this);
        searchResults.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams resultsP = new LinearLayout.LayoutParams(-1, -2);
        resultsP.topMargin = dp(9);
        body.addView(searchResults, resultsP);
        cityInput.requestFocus();
    }

    private void setSearchStatus(String msg) {
        if (searchPage && searchStatus != null) searchStatus.setText(msg);
    }

    private void showSearchResults(String[] labels, JSONArray matches) {
        if (!searchPage || searchResults == null) return;
        searchResults.removeAllViews();
        for (int i = 0; i < labels.length; i++) {
            final int selectedIndex = i;
            TextView choice = actionChip(labels[i]);
            choice.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
            choice.setPadding(dp(17), 0, dp(12), 0);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(53));
            p.topMargin = dp(7);
            searchResults.addView(choice, p);
            focusControl(choice);
            choice.setOnClickListener(v -> {
                JSONObject selected = matches.optJSONObject(selectedIndex);
                if (selected == null) return;
                latitude = selected.optDouble("latitude", latitude);
                longitude = selected.optDouble("longitude", longitude);
                city = labels[selectedIndex];
                prefs.edit().putLong("lat", Double.doubleToRawLongBits(latitude))
                        .putLong("lon", Double.doubleToRawLongBits(longitude))
                        .putString("city", city).remove("cache").remove("cached_at").apply();
                requestSequence++;
                buildScreen();
                clearCurrentWeather();
                loadWeather();
            });
        }
    }

    private void returnHome() {
        buildScreen();
        String cached = prefs.getString("cache", "");
        if (!cached.isEmpty()) {
            try {
                render(new JSONObject(cached));
                statusView.setText("缓存天气 · 可下翻刷新");
            } catch (Exception ignored) { loadWeather(); }
        } else {
            loadWeather();
        }
    }

    @Override public void onBackPressed() {
        if (searchPage) returnHome();
        else super.onBackPressed();
    }

    private void clearCurrentWeather() {
        tempView.setText("--°");
        weatherEmoji.setText("🌤️");
        weatherView.setText("正在加载天气");
        updateView.setText("当地时间 --");
        for (TextView value : detailValue) if (value != null) value.setText("--");
    }

    private void showSkeleton() {
        hourRow.removeAllViews();
        daysList.removeAllViews();
        hourRow.addView(text("正在获取未来24小时预报…", 15, MUTED, false));
        daysList.addView(text("正在获取未来7天天气…", 15, MUTED, false));
    }

    private void searchCities() {
        if (!searchPage || cityInput == null) return;
        String query = cityInput.getText().toString().trim();
        if (query.length() < 2) {
            toast("请输入至少两个字符的城市名");
            return;
        }
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(cityInput.getWindowToken(), 0);
        cityInput.clearFocus();
        setSearchStatus("正在搜索城市…");
        searchResults.removeAllViews();
        io.execute(() -> {
            try {
                String address = "https://geocoding-api.open-meteo.com/v1/search?name="
                        + URLEncoder.encode(query, "UTF-8") + "&count=8&language=zh&format=json";
                JSONObject response = new JSONObject(httpGet(address));
                JSONArray places = response.optJSONArray("results");
                if (places == null || places.length() == 0) {
                    ui(() -> setSearchStatus("没有找到城市，请尝试英文或西语"));
                    return;
                }
                final JSONArray matches = places;
                String[] labels = new String[matches.length()];
                for (int i = 0; i < labels.length; i++) {
                    JSONObject p = matches.getJSONObject(i);
                    String admin = p.optString("admin1", "");
                    String country = p.optString("country", "");
                    labels[i] = p.optString("name") + (admin.isEmpty() ? "" : " · " + admin)
                            + (country.isEmpty() ? "" : " · " + country);
                }
                ui(() -> {
                    setSearchStatus("找到 " + labels.length + " 个匹配结果");
                    showSearchResults(labels, matches);
                });
            } catch (Exception e) {
                ui(() -> { setSearchStatus("城市搜索失败，请检查网络"); toast("搜索失败，请重试"); });
            }
        });
    }

    private void loadWeather() {
        final int myRequest = ++requestSequence;
        final double lat = latitude;
        final double lon = longitude;
        statusView.setText("正在更新天气…");
        io.execute(() -> {
            try {
                String url = "https://api.open-meteo.com/v1/forecast?latitude="
                        + String.format(Locale.US, "%.5f", lat)
                        + "&longitude=" + String.format(Locale.US, "%.5f", lon)
                        + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m"
                        + "&hourly=temperature_2m,precipitation_probability,weather_code"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset"
                        + "&forecast_days=7&timezone=auto";
                String json = httpGet(url);
                JSONObject response = new JSONObject(json);
                if (response.optBoolean("error", false)) throw new Exception(response.optString("reason"));
                response.getJSONObject("current");
                response.getJSONObject("hourly");
                response.getJSONObject("daily");
                ui(() -> {
                    if (myRequest != requestSequence) return;
                    try {
                        render(response);
                        String localTime = response.optJSONObject("current").optString("time", "");
                        statusView.setText("天气更新于 " + displayTime(localTime));
                        prefs.edit().putString("cache", json)
                                .putLong("cached_at", System.currentTimeMillis()).apply();
                    } catch (Exception e) {
                        statusView.setText("天气数据解析失败，请重试");
                    }
                });
            } catch (Exception e) {
                ui(() -> {
                    if (myRequest != requestSequence) return;
                    statusView.setText(prefs.contains("cache") ? "网络不可用 · 显示上次缓存" : "天气加载失败 · 请检查网络后刷新");
                    toast("天气请求失败，请检查网络");
                });
            }
        });
    }

    private void render(JSONObject response) throws Exception {
        JSONObject current = response.getJSONObject("current");
        int code = current.optInt("weather_code", 0);
        boolean isDay = current.optInt("is_day", 1) == 1;
        hero.setBackground(heroBackground(isDay, code));
        cityView.setText(city);
        tempView.setText(roundTemperature(current.optDouble("temperature_2m", Double.NaN)) + "°");
        weatherEmoji.setText(emoji(code, isDay));
        weatherView.setText(weatherName(code));
        updateView.setText("当地时间  " + displayTime(current.optString("time", "")));
        detailValue[0].setText(roundTemperature(current.optDouble("apparent_temperature", Double.NaN)) + "°C");
        detailValue[1].setText(whole(current.optDouble("relative_humidity_2m", Double.NaN)) + "%");
        detailValue[2].setText(whole(current.optDouble("wind_speed_10m", Double.NaN)) + " km/h");
        detailValue[3].setText(oneDecimal(current.optDouble("precipitation", Double.NaN)) + " mm");

        JSONObject hourly = response.getJSONObject("hourly");
        JSONArray times = hourly.getJSONArray("time");
        JSONArray temperatures = hourly.getJSONArray("temperature_2m");
        JSONArray chances = hourly.getJSONArray("precipitation_probability");
        JSONArray hourlyCodes = hourly.getJSONArray("weather_code");
        String currentHour = current.optString("time", "");
        if (currentHour.length() >= 13) currentHour = currentHour.substring(0, 13);
        int start = Math.max(0, times.length() - 24);
        for (int i = 0; i < times.length(); i++) {
            String at = times.optString(i, "");
            if (at.length() >= 13 && at.substring(0, 13).compareTo(currentHour) >= 0) {
                start = i;
                break;
            }
        }
        hourRow.removeAllViews();
        int count = Math.min(24, times.length() - start);
        int cardWidth = Math.max(85, Math.min(130, (screenWidthDp - 112) / 9));
        for (int i = 0; i < count; i++) {
            int j = i + start;
            String at = times.optString(j, "");
            String hour = at.length() >= 16 ? at.substring(11, 16) : "--:--";
            int forecastCode = hourlyCodes.optInt(j, 0);
            String degree = roundTemperature(temperatures.optDouble(j, Double.NaN));
            String rainChance = whole(chances.optDouble(j, Double.NaN));
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(dp(4), dp(3), dp(4), dp(3));
            int base = i == 0 ? 0xFF275474 : TILE;
            tile.setBackground(round(base, 13));
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(cardWidth), -1);
            if (i > 0) hp.leftMargin = dp(7);
            hourRow.addView(tile, hp);
            TextView hourLabel = text(i == 0 ? "现在" : hour, compact ? 12 : 15, MUTED, true);
            hourLabel.setGravity(Gravity.CENTER);
            tile.addView(hourLabel);
            TextView icon = text(emoji(forecastCode, true), compact ? 21 : 30, WHITE, false);
            icon.setGravity(Gravity.CENTER);
            tile.addView(icon);
            TextView degrees = text(degree + "°", compact ? 19 : 25, WHITE, true);
            degrees.setGravity(Gravity.CENTER);
            tile.addView(degrees);
            TextView rain = text("☂ " + rainChance + "%", compact ? 11 : 14, BLUE, false);
            rain.setGravity(Gravity.CENTER);
            tile.addView(rain);
            String description = hour + " " + weatherName(forecastCode) + " " + degree
                    + "度，降雨概率 " + rainChance + "%";
            tile.setContentDescription(description);
            tile.setOnClickListener(v -> toast(description));
            focusTile(tile, base);
        }

        JSONObject daily = response.getJSONObject("daily");
        JSONArray dates = daily.getJSONArray("time");
        JSONArray high = daily.getJSONArray("temperature_2m_max");
        JSONArray low = daily.getJSONArray("temperature_2m_min");
        JSONArray dayCodes = daily.getJSONArray("weather_code");
        JSONArray precip = daily.getJSONArray("precipitation_probability_max");
        daysList.removeAllViews();
        for (int i = 0; i < Math.min(7, dates.length()); i++) {
            String date = dates.optString(i, "");
            int dayCode = dayCodes.optInt(i, 0);
            String hi = roundTemperature(high.optDouble(i, Double.NaN));
            String lo = roundTemperature(low.optDouble(i, Double.NaN));
            String chance = whole(precip.optDouble(i, Double.NaN));
            String label = i == 0 ? "今天" : shortDay(date);
            LinearLayout tile = new LinearLayout(this);
            tile.setGravity(Gravity.CENTER);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setPadding(dp(3), dp(3), dp(3), dp(3));
            int base = i == 0 ? 0xFF275474 : TILE;
            tile.setBackground(round(base, 13));
            LinearLayout.LayoutParams cardP = new LinearLayout.LayoutParams(0, -1, 1);
            if (i > 0) cardP.leftMargin = dp(7);
            daysList.addView(tile, cardP);
            TextView day = text(label, compact ? 13 : 17, WHITE, true);
            day.setGravity(Gravity.CENTER);
            tile.addView(day);
            TextView symbol = text(emoji(dayCode, true), compact ? 22 : 30, WHITE, false);
            symbol.setGravity(Gravity.CENTER);
            tile.addView(symbol);
            TextView weather = text(weatherName(dayCode), compact ? 10 : 13, MUTED, false);
            weather.setGravity(Gravity.CENTER);
            weather.setSingleLine(true);
            tile.addView(weather);
            TextView temperaturesView = text(hi + "° / " + lo + "°", compact ? 14 : 20, WHITE, true);
            temperaturesView.setGravity(Gravity.CENTER);
            temperaturesView.setSingleLine(true);
            tile.addView(temperaturesView);
            TextView rain = text("☂ " + chance + "%", compact ? 11 : 14, BLUE, false);
            rain.setGravity(Gravity.CENTER);
            tile.addView(rain);
            String description = label + " " + weatherName(dayCode) + "，最高 " + hi
                    + "度，最低 " + lo + "度，降雨概率 " + chance + "%";
            tile.setContentDescription(description);
            tile.setOnClickListener(v -> toast(description));
            focusTile(tile, base);
        }
    }

    private void locateMe() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION }, REQUEST_LOCATION);
            return;
        }
        if (awaitingLocation) { toast("正在定位，请稍候"); return; }
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) { toast("无法使用定位服务"); return; }
        String provider = null;
        try {
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                provider = LocationManager.NETWORK_PROVIDER;
            } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                provider = LocationManager.GPS_PROVIDER;
            }
        } catch (Exception ignored) { }
        if (provider == null) { toast("请先开启电视定位服务"); return; }
        final String selectedProvider = provider;
        try {
            statusView.setText("正在获取电视位置…");
            Location last = locationManager.getLastKnownLocation(selectedProvider);
            if (last != null && System.currentTimeMillis() - last.getTime() < 20 * 60 * 1000L) {
                useLocation(last);
                return;
            }
            awaitingLocation = true;
            locationListener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    if (!awaitingLocation) return;
                    awaitingLocation = false;
                    locationManager.removeUpdates(this);
                    locationListener = null;
                    useLocation(location);
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
                @Override public void onProviderEnabled(String provider) { }
                @Override public void onProviderDisabled(String provider) { }
            };
            LocationListener activeListener = locationListener;
            locationManager.requestSingleUpdate(selectedProvider, activeListener, Looper.getMainLooper());
            main.postDelayed(() -> {
                if (!awaitingLocation || locationListener != activeListener) return;
                awaitingLocation = false;
                try { locationManager.removeUpdates(activeListener); } catch (Exception ignored) { }
                locationListener = null;
                if (last != null) useLocation(last);
                else { statusView.setText("定位超时，请尝试搜索城市"); toast("定位超时，可手动搜索城市"); }
            }, 15000);
        } catch (SecurityException se) {
            awaitingLocation = false;
            toast("定位权限不足，请检查电视设置");
        } catch (Exception e) {
            awaitingLocation = false;
            toast("定位失败，请使用城市搜索");
        }
    }

    private void useLocation(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        city = "我的位置";
        cityView.setText(city);
        prefs.edit().putLong("lat", Double.doubleToRawLongBits(latitude))
                .putLong("lon", Double.doubleToRawLongBits(longitude))
                .putString("city", city).remove("cache").remove("cached_at").apply();
        clearCurrentWeather();
        showSkeleton();
        loadWeather();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) locateMe();
            else toast("没有定位权限，可通过城市搜索查看天气");
        }
    }

    private String httpGet(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(12000);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", "CloudSkyWeather/1.0 (Android TV; Open-Meteo client)");
        try {
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            if (stream == null) throw new Exception("HTTP " + status);
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            StringBuilder builder = new StringBuilder();
            String line;
            try {
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                    if (builder.length() > 1500000) throw new Exception("Response too large");
                }
            } finally { reader.close(); }
            if (status < 200 || status >= 300) throw new Exception("HTTP " + status + ": " + builder);
            return builder.toString();
        } finally { connection.disconnect(); }
    }

    private void ui(Runnable action) {
        main.post(() -> { if (!destroyed && !isFinishing()) action.run(); });
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable heroBackground(boolean day, int code) {
        int[] colors;
        if (!day) colors = new int[]{0xFF1C3756, 0xFF10263E};
        else if (code >= 51 && code <= 82) colors = new int[]{0xFF326889, 0xFF224D73};
        else colors = new int[]{0xFF366D96, 0xFF24517B};
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(22));
        return d;
    }

    private TextView actionChip(String label) {
        TextView t = text(label, 17, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(0xFF244967, 13));
        return t;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(float size) { return (int) (size * getResources().getDisplayMetrics().density + 0.5f); }

    private String roundTemperature(double v) { return Double.isNaN(v) ? "--" : String.format(Locale.CHINA, "%.0f", v); }
    private String whole(double v) { return Double.isNaN(v) ? "--" : String.format(Locale.CHINA, "%.0f", v); }
    private String oneDecimal(double v) { return Double.isNaN(v) ? "--" : String.format(Locale.CHINA, "%.1f", v); }
    private String displayTime(String iso) { return iso.length() >= 16 ? iso.substring(0, 10) + " " + iso.substring(11, 16) : "--"; }

    private String shortDay(String raw) {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(raw);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(d);
            String[] days = {"", "周日", "周一", "周二", "周三", "周四", "周五", "周六"};
            return days[calendar.get(Calendar.DAY_OF_WEEK)];
        } catch (Exception ignored) { return raw; }
    }

    private String weatherName(int code) {
        if (code == 0) return "晴朗";
        if (code == 1) return "大致晴朗";
        if (code == 2) return "局部多云";
        if (code == 3) return "阴天";
        if (code == 45 || code == 48) return "有雾";
        if (code >= 51 && code <= 57) return "毛毛雨";
        if (code == 61 || code == 80) return "小雨";
        if (code == 63 || code == 81) return "中雨";
        if (code == 65 || code == 82) return "大雨";
        if (code == 66 || code == 67) return "冻雨";
        if (code >= 71 && code <= 77) return "降雪";
        if (code >= 85 && code <= 86) return "阵雪";
        if (code == 95) return "雷雨";
        if (code == 96 || code == 99) return "雷暴冰雹";
        return "天气变化";
    }

    private String emoji(int code, boolean day) {
        if (code == 0) return day ? "☀️" : "🌙";
        if (code == 1 || code == 2) return day ? "🌤️" : "🌙";
        if (code == 3) return "☁️";
        if (code == 45 || code == 48) return "🌫️";
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "🌧️";
        if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) return "🌨️";
        if (code >= 95) return "⛈️";
        return "🌥️";
    }

    @Override protected void onDestroy() {
        destroyed = true;
        requestSequence++;
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        }
        io.shutdownNow();
        super.onDestroy();
    }
}
