# 云端天气 · Google TV V1

这是从 `CloudSky-Weather-Watch8-v2-OneUpload.zip` 的 Java 源码独立移植出的 Android TV 天气 App；非 WebView，不需要手机端配合。

## TV 首页与遥控器

- **上方：当前天气**：城市、温度、天气状态、体感温度、湿度、风速、当前降水、更新状态。
- **中间：未来 24 小时**：逐小时温度、天气、降雨概率。卡片支持电视遥控器方向键左右焦点移动，24 小时数据可以全部查看（不要求把 24 列挤在同一屏）。
- **下方：未来 7 天**：7 列同时显示每天的星期、天气、最高最低温、降水概率。
- 三个区域合计恰好占一页 TV 横屏；按 **↓** 继续浏览下方设置（刷新、定位、全球城市搜索、更新时间）。
- **确定**键查看预测摘要或激活设置；搜索页支持电视系统输入法与返回键。
- 主页字体大小和栏高会按屏幕 dp 尺寸缩放。适合 Google TV / Android TV 常见 16:9 横屏。

## 完全保留天气 API 与已有功能

- 天气源不变：`https://api.open-meteo.com/v1/forecast`
- `current`、`hourly`、`daily` 全部字段与用户提供的手表源码**完全相同**；`forecast_days=7&timezone=auto` 原样保留。
- 全球城市搜索不变：`https://geocoding-api.open-meteo.com/v1/search?name=...&count=8&language=zh&format=json`
- 缓存、手动刷新、坐标选择/持久化、网络失败时缓存回退逻辑不变。
- TV 无 GPS 时定位功能可能不可用，可通过“搜索全球城市”切换位置。
- **新安装包名**：`com.cloudsky.weather.tv`，不会覆盖原手表安装包（`com.cloudsky.weather.watch`）。
- 首次安装默认 Buenos Aires，城市可搜索切换（TV 版与手表版不共享保存城市）。

## GitHub Actions 编译——单 ZIP 上传方式

1. 到 https://github.com/new 新建仓库，例如 `CloudSky-Weather-TV`（公开或私有均可）。
2. 在 GitHub 网页 **Add file → Upload files** 中上传 `CloudSky-Weather-TV-v1-OneUpload.zip` 到仓库根目录（ZIP **不用**解压）。
3. 在仓库网页 **Add file → Create new file**，文件名完整输入 `.github/workflows/build-tv-apk.yml`，粘贴本次提供的 `build-tv-apk.yml` 文件内容并提交。注意：仅在 ZIP 内包含工作流，GitHub 不会自动识别；第3步是必须的。
4. 仓库 **Actions → Build CloudSky Weather TV APK → Run workflow**（若 push 已触发则可直接打开该任务）。
5. 绿色成功后，到该次任务下的 **Artifacts** 下载 `CloudSky-Weather-TV-v1-APK`，解压即可获得 `CloudSky-Weather-TV-v1.apk`。
6. 通过 USB/ADB 或本地安装器装到 Google TV；电视 Launcher 中将出现 **云端天气 TV**。

也可以把 ZIP 解压后把全部源码（包括 `.github/workflows/build-tv-apk.yml` 隐藏目录）上传到仓库，Actions 可直接按源码编译，无需单独创建第3步。

## 编译参数

Java 17、Android Gradle Plugin 8.9.2、Gradle 8.11.1、compileSdk 35、minSdk 26、targetSdk 35。原生 Java，无第三方 Android UI/网络 SDK 依赖。

## 验证状态

已完成源码迁移、工作流、包名/TV Launcher Manifest 与静态结构核对；此运行环境没有 Android SDK/Gradle，因此尚未在本地编译为 APK，也未在真实电视设备上测试最终字号、遥控器焦点与画面裁切，必须以 GitHub Actions 和电视设备测试为准。
